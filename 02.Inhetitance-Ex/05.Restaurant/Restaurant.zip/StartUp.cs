﻿namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Coffee coffee = new Coffee("LM", 2.5);
            System.Console.WriteLine();
        }
    }
}