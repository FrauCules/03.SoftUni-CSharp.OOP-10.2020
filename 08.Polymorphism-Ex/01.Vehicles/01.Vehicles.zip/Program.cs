﻿using _01.Vehicles.Core;

namespace _01.Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
