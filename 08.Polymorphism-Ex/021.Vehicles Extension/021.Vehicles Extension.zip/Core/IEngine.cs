﻿namespace _021.VehiclesExtention.Core
{
    public interface IEngine
    {
        void Run();
    }
}
